__nowaiting = true	-- If you turn this flag off, cluster.call would block when node name is absent

db = "127.0.0.1:2528"
db2 = "127.0.0.1:2529"
